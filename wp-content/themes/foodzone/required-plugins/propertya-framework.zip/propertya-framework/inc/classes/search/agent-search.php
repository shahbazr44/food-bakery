<?php
// Ajax handler for Pagination
add_action( 'wp_ajax_prop_agent_search', 'propertya_framework_agent_search' );
add_action( 'wp_ajax_nopriv_prop_agent_search', 'propertya_framework_agent_search' );
if (!function_exists ( 'propertya_framework_agent_search' ))
{
	function propertya_framework_agent_search()
	{
		$params = array();
		parse_str($_POST['collect_data'], $params);
		$page_no = '';
        if (isset($_POST['page_no'])) {
            $page_no = $_POST['page_no'];
        } else {
            $page_no = 1;
        }
		$filter_html = '<div class="filter-tags"><ul class="filter-tags-list"><li class="filter-tags-render"><span class="filter-reset">'.esc_html__( 'Clear All', 'propertya-framework' ).':</span>'.esc_html__( 'Filters', 'propertya-framework' ).'<a href="javascript:void(0)" id="reset_ajax_result" class="filter-reset-btn">×</a></li></ul></div>';
		//Listing Title
        $title = '';
        if (isset($params['by_title']) && $params['by_title'] != "") {
            $title = $params['by_title'];
        }
		$by_location = '';
        if (isset($params['by_location']) && $params['by_location'] != "") {
			$by_location = array(
				array(
					'taxonomy' => 'agent_location',
					'field' => 'slug',
					'terms' => $params['by_location'],
				),
			);
        }
		$by_type = '';
        if (isset($params['by_type']) && $params['by_type'] != "") {
			$by_type = array(
				array(
					'taxonomy' => 'agent_types',
					'field' => 'slug',
					'terms' => $params['by_type'],
				),
			);
        }
		//near me
		$lat_lng_meta_query = $data_array = array();
		if (isset($params['latt']) && $params['latt'] != "" && isset($params['long']) && $params['long'] != "" && isset($params['distance']) && $params['distance'] != "")
		{
			$latt = $params['latt'];
			$long = $params['long'];
			$distance = $params['distance'];
			$data_array = array("latitude" => $latt, "longitude" => $long, "distance" => $distance);
			$lats_longs = propertya_min_max_latt_long($data_array);
			if(is_array($lats_longs) && !empty($lats_longs) && count($lats_longs) > 0)
			{
				$lat_lng_meta_query[] = array(
                    'key' => 'agent_latt',
                    'value' => array($lats_longs['lat']['min'], $lats_longs['lat']['max']),
                    'compare' => 'BETWEEN',
                    'type' => 'DECIMAL',
                );
				$lat_lng_meta_query[] = array(
                    'key' => 'agent_long',
                    'value' => array($lats_longs['long']['min'], $lats_longs['long']['max']),
                    'compare' => 'BETWEEN',
                    'type' => 'DECIMAL',
                );
				add_filter('get_meta_sql', 'propertya_decimal_precision');
				if (!function_exists('propertya_decimal_precision'))
				{
                    function propertya_decimal_precision($array)
					{
                        $array['where'] = str_replace('DECIMAL', 'DECIMAL(10,3)', $array['where']);
                        return $array;
                    }
                }
			}
		}
		//sorting
		$order = 'DESC';
		$orderby = array(
		    'meta_value' => 'DESC',
			'post_date'      => 'DESC',
		);
		if (isset($_POST['sort_by']) && $_POST['sort_by'] != "") {
			
			$sort_type = $_POST['sort_by'];
			//oldest
			if($sort_type == 'oldest')
			{
				$orderby = array(
					'meta_value' => 'ID',
					'post_date'      => 'ASC',
				);
				$order = 'ASC';
			}
			//newset
			if($sort_type == 'newest')
			{
				$orderby = array(
					'meta_value' => 'DESC',
					'post_date'      => 'DESC',
				);
				$order = 'DESC';
			}
			//title asc
			if($sort_type == 'title-asc')
			{
				$orderby = array(
					'meta_value' => 'DESC',
					'title' => 'ASC'
				);
				$order = 'ASC';
			}
			//tile desc
			if($sort_type == 'title-desc')
			{
				$orderby = array(
					'meta_value' => 'DESC',
					'title' => 'DESC'
				);
				$order = 'DESC';
			}
			
		}
		$args	=	array
	    (
		's' => $title,
		'post_type' => 'property-agents',
		'post_status' => 'publish',
		'posts_per_page' => get_option('posts_per_page'),
		'paged' => $page_no,
        'fields' => 'ids',
		'meta_key' => 'agent_is_featured',
		'meta_query'    => array(
			array(
				'key'       => 'agent_status',
				'value'     => '1',
				'compare'   => '=',
			),
			$lat_lng_meta_query
		),
		'tax_query' => array(
			$by_location,
			$by_type
		),
		'orderby'  => $orderby,
		'order'=> $order,
	  );
	   $results = new WP_Query( $args );
	   $fetch_output = '';
       if ($results->have_posts())
	   {
		   require trailingslashit(get_template_directory()) . 'template-parts/search/agent-search/grids/grids.php';
		   $return = array('total_results' => $results->found_posts  ,'pagination' => propertya_pagination_search($results, $page_no) , 'fliters' => $filter_html,  'listings' => $fetch_output);
		   wp_send_json_success($return);
	   }
	   else
	   {
		   
		   $no_result = propertya_framework_no_result_found();
		   $return = array('fliters' => $filter_html,  'no_result' => $no_result,'total_results' => $results->found_posts );
		   wp_send_json_error($return);
	   }
	}
}


// Ajax handler for Suggestions
add_action( 'wp_ajax_prop_agent_search_suggestions', 'propertya_framework_agent_search_suggestions' );
add_action( 'wp_ajax_nopriv_prop_agent_search_suggestions', 'propertya_framework_agent_search_suggestions' );
if (!function_exists ( 'propertya_framework_agent_search_suggestions' ))
{
	function propertya_framework_agent_search_suggestions()
	{
		if (!empty($_GET['q']))
		{
			$return = array();
			$keyword = trim(strtolower(esc_sql($_GET['q'])));
			$search_results = new WP_Query(array(
                's' => $keyword,
                'post_type' => 'property-agents',
                'post_status' => 'publish',
                'posts_per_page' => 15,
                'fields' => 'ids',
				'meta_query'    => array(
				array(
						'key'       => 'agent_status',
						'value'     => '1',
						'compare'   => '=',
					),
				),
            ));
			if ($search_results->have_posts())
			{
				while ($search_results->have_posts())
				{
					 $search_results->the_post();
                     $agent_id = get_the_ID();
					 $title = get_the_title($agent_id);
					 $return[] = propertya_clean_titles($title);
				}
				wp_reset_postdata();
			}
			echo json_encode($return);
		}
		die();
	}
}